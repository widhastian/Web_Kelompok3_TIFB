@extends('layouts.admin.main')

@section('content-admin')
    <h1>Selamat Datang Admin :)</h1>
@endsection
