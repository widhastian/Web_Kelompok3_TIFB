<link href="{{ asset('admin/img/logo/logo.png') }}" rel="icon">
<link href="{{ asset('admin/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('admin/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('admin/css/ruang-admin.min.css') }}" rel="stylesheet">
<link href="{{ asset('admin/css/chat.css') }}" rel="stylesheet">
<!-- DataTables -->
<link rel="stylesheet" href="{{ asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css') }}">

{{-- Trix Editor --}}
<link rel="stylesheet" type="text/css" href="{{ asset('admin/css/trix.css') }}">
<script type="text/javascript" src="{{ asset('admin/js/trix.js') }}"></script>
