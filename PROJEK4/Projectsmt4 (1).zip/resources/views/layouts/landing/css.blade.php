<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900&display=swap"
    rel="stylesheet">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="{{ asset('landing/css/animate.css') }}">

<link rel="stylesheet" href="{{ asset('landing/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('landing/css/owl.theme.default.min.css') }}">
<link rel="stylesheet" href="{{ asset('landing/css/magnific-popup.css') }}">

<link rel="stylesheet" href="{{ asset('landing/css/flaticon.css') }}">
<link rel="stylesheet" href="{{ asset('landing/css/style.css') }}">
<link rel="stylesheet" href="{{ asset('landing/css/chat.css') }}">
