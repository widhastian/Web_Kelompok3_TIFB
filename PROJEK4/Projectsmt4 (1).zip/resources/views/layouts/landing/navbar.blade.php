<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container-fluid">
        <img style="border-radius: 150px; width: 50px;" src="{{ asset('landing/images/logo.jpeg') }}">
        <a class="navbar-brand" style="padding-left: 20px;" href="index.html">GoFarm</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
            aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                @guest
                    <li class="nav-item {{ Nav::isRoute('home') }}"><a href="{{ route('home') }}"
                            class="nav-link">Home</a></li>
                    <li class="nav-item {{ Nav::isRoute('login') }}"><a href="{{ route('login') }}"
                            class="nav-link">Login</a></li>
                @else
                    <li class="nav-item {{ Nav::isRoute('home') }}"><a href="{{ route('home') }}"
                            class="nav-link">Home</a></li>
                    <li class="nav-item {{ Nav::isRoute('landing-chat') }}"><a href="{{ route('landing-chat') }}"
                            class="nav-link">Chat</a></li>

                    <li class="nav-item"><a href="agent.html" class="nav-link">Artikel</a></li>
                    <li class="nav-item"> <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                                         document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </li>
                    <li class="nav-item"><img style="border-radius: 150px; width: 50px; margin-left: 70px;"
                            src="{{ asset('landing/images/person_1.jpg') }}"></li>
                    <li class="nav-item"><a href="contact.html"
                            class="nav-link">{{ $nama = Auth::user() ? Auth::user()->name : '' }}</a>
                    </li>
                @endguest
            </ul>
        </div>
    </div>
</nav>
<!-- END nav -->
