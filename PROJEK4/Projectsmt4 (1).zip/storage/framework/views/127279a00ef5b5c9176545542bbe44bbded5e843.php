  <!-- Offcanvas Menu Begin -->
  <div class="offcanvas-menu-overlay"></div>
  <div class="offcanvas-menu-wrapper">
      <div class="offcanvas__option">
          <div class="offcanvas__links">
              <a href="#">Sign in</a>
              <a href="#">FAQs</a>
          </div>
      </div>
      <div class="offcanvas__nav__option">
          <a href="#" class="search-switch"><img src="img/icon/search.png" alt=""></a>
          <a href="#"><img src="img/icon/heart.png" alt=""></a>
          <a href="#"><img src="img/icon/cart.png" alt=""> <span>0</span></a>
          <div class="price">$0.00</div>
      </div>
      <div id="mobile-menu-wrap"></div>
      <div class="offcanvas__text">
          <p>Free shipping, 30-day return or refund guarantee.</p>
      </div>
  </div>
  <!-- Offcanvas Menu End -->
  <header class="header">
      <div class="container">
          <div class="row">
              <div class="col-lg-3 col-md-3">
                  <div class="header__logo">
                      <a href="."><img src="<?php echo e(asset('assets/frontend/img/logo.png')); ?>" alt=""></a>
                  </div>
              </div>
              <div class="col-lg-6 col-md-6">
                  <nav class="header__menu mobile-menu">
                      <ul>
                          <li class="<?php echo e(Nav::isRoute('home')); ?>">
                              <a href="<?php echo e(route('home')); ?>">Home</a>
                          </li>
                          
                      </ul>
                  </nav>
              </div>
              <div class="col-lg-3 col-md-3">
                  <div class="header__nav__option">
                      <a href="#" class="search-switch"><img src="<?php echo e(asset('assets/frontend/img/icon/search.png')); ?>"
                              alt=""></a>
                      <a href="#"><img src="<?php echo e(asset('assets/frontend/img/icon/heart.png')); ?>" alt=""></a>
                      <a href="#"><img src="<?php echo e(asset('assets/frontend/img/icon/cart.png')); ?>" alt="">
                          <span>0</span></a>
                      <div class="price">$0.00</div>
                  </div>
              </div>
          </div>
          <div class="canvas__open"><i class="fa fa-bars"></i></div>
      </div>
  </header>
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/frontend/navbar.blade.php ENDPATH**/ ?>