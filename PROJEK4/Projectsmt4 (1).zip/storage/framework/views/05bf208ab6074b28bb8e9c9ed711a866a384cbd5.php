 <script src="<?php echo e(asset('landing/js/jquery.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/popper.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/bootstrap.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery.easing.1.3.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery.waypoints.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery.stellar.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/owl.carousel.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery.magnific-popup.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/jquery.animateNumber.min.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/scrollax.min.js')); ?>"></script>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
 <script src="<?php echo e(asset('landing/js/google-map.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/main.js')); ?>"></script>
 <script src="<?php echo e(asset('landing/js/chat.js')); ?>"></script>
 
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/landing/js.blade.php ENDPATH**/ ?>