 <link href="<?php echo e(asset('landingpage/chat.css')); ?>">
 
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/landingpage/css.blade.php ENDPATH**/ ?>