    <!-- Js Plugins -->
    <script src="<?php echo e(asset('assets/frontend/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/jquery.countdown.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/jquery.slicknav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/frontend/js.blade.php ENDPATH**/ ?>