 <!-- Modal -->
 <div class="modal fade" id="modalEditKec<?php echo e($kec->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Edit Data Kecamatan</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             
             <form action="<?php echo e(route('admin-UpdateKec', $kec->id)); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <div class="modal-body">
                     <div class="form-group">
                         <label for="Nama">Nama Kecamatan</label>
                         <input type="text" class="form-control" name="nama_kecamatan" id="nama_kecamatan"
                             placeholder="Enter Nama " value="<?php echo e($kec->nama_kecamatan); ?>">
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Simpan</button>
                 </div>
             </form>
             
         </div>
     </div>
 </div>
<?php /**PATH C:\xampp\htdocs\Projectsmt4Asli - Copy\resources\views/contentadmin/kecamatan/edit-kecamatan.blade.php ENDPATH**/ ?>