<?php $__env->startSection('content-admin'); ?>
    <h1>Selamat Datang Admin :)</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_A\Projectsmt4\resources\views/contentadmin/beranda.blade.php ENDPATH**/ ?>