<!DOCTYPE html>
<html lang="en">

<head>
    <title>ArcLab - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php echo $__env->make('layouts.landing.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php echo $__env->yieldPushContent('style-custom'); ?>
</head>

<body>
    <?php echo $__env->make('layouts.landing.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content-landing'); ?>
    <?php echo e(isset($slot) ? $slot : null); ?>



    
    <?php echo $__env->make('layouts.landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
        <svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
                stroke="#F96D00" />
        </svg>
    </div>


    <?php echo $__env->make('layouts.landing.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('script-custom'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/landing/main.blade.php ENDPATH**/ ?>