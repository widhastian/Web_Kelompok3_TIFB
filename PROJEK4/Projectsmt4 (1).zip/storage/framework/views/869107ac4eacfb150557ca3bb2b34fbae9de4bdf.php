<link href="<?php echo e(asset('admin/img/logo/logo.png')); ?>" rel="icon">
<link href="<?php echo e(asset('admin/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/css/ruang-admin.min.css')); ?>" rel="stylesheet">
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">


<link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin/css/trix.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('admin/js/trix.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\Projectsmt4\resources\views/layouts/admin/css.blade.php ENDPATH**/ ?>