 <!-- Modal -->
 <div class="modal fade" id="modalEditKtg<?php echo e($ktg->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Edit Data Kategori</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             
             <form action="<?php echo e(route('admin-kategoriUpdate', $ktg->id)); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <div class="modal-body">
                     <div class="form-group">
                         <label for="Nama">Nama Kategori</label>
                         <input type="text" class="form-control" name="nama_kategori" id="nama_kategori"
                             placeholder="Enter Nama " value="<?php echo e($ktg->nama_kategori); ?>">
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Simpan</button>
                 </div>
             </form>
             
         </div>
     </div>
 </div>
<?php /**PATH C:\xampp\htdocs\Projectsmt4Asli - Copy\resources\views/contentadmin/kategori/edit-kategori.blade.php ENDPATH**/ ?>