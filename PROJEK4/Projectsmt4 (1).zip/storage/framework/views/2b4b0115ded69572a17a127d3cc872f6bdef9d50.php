<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600;700;800;900&display=swap"
    rel="stylesheet">

<!-- Css Styles -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/font-awesome.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/elegant-icons.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/magnific-popup.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/nice-select.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/owl.carousel.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/slicknav.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" type="text/css">
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/frontend/css.blade.php ENDPATH**/ ?>