<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon">
            <img src="<?php echo e(asset('admin/img/logo/logo.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3">CFarmer</div>
    </a>
    <hr class="sidebar-divider my-0">
    <li class="nav-item <?php echo e(Nav::isRoute('home')); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <?php if(Auth::user()->id_level == 1): ?>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-petugas')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-petugas')); ?>">
                <i class="fas fa-fw fa-user-alt"></i>
                <span>Petugas</span></a>
        </li>
    <?php endif; ?>
    <?php if(Auth::user()->id_level != 3): ?>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-kecamatan')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-kecamatan')); ?>">
                <i class="fas fa-fw fa-file-alt"></i>
                <span>Kecamatan</span></a>
        </li>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-desa')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-desa')); ?>">
                <i class="fas fa-fw fa-file-alt"></i>
                <span>Desa</span></a>
        </li>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-kategori')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-kategori')); ?>">
                <i class="fas fa-fw fa-file-alt"></i>
                <span>Kategori</span></a>
        </li>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-artikel')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-artikel')); ?>">
                <i class="fas fa-fw fa-file-alt"></i>
                <span>Artikel</span></a>
        </li>
        <li class="nav-item <?php echo e(Nav::isRoute('admin-chat')); ?>">
            <a class="nav-link" href="<?php echo e(route('admin-chat')); ?>">
                <i class="fas fa-fw fa-file-alt"></i>
                <span>Chat</span></a>
        </li>
    <?php endif; ?>

    
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </li>
    
    <hr class="sidebar-divider">
    <div class="version" id="version-ruangadmin"></div>
</ul>
<!-- Sidebar -->
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>