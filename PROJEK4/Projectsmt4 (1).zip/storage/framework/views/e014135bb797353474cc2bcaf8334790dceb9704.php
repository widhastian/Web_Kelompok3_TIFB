 <!-- Modal -->
 <div class="modal fade" id="modalEditDes<?php echo e($des->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Edit Data Desa</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             
             <form action="<?php echo e(route('admin-UpdateDes', $des->id)); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <div class="modal-body">
                     <div class="form-group">
                         <label for="kecamatan-option">Nama Kecamatan</label>
                         <select class="form-control" id="id_kecamatan" name="id_kecamatan">
                             <option><?php echo e($des->kecFK->nama_kecamatan); ?></option>
                             <option>-Pilih Kecamatan-</option>
                             <?php $__currentLoopData = $dataKecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($dk->id); ?>"><?php echo e($dk->nama_kecamatan); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                     </div>
                     <div class="form-group">
                         <label for="Nama">Nama Desa</label>
                         <input type="text" class="form-control" name="nama_desa" id="nama_desa"
                             placeholder="Enter Nama " value="<?php echo e($des->nama_desa); ?>">
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Simpan</button>
                 </div>
             </form>
             
         </div>
     </div>
 </div>
<?php /**PATH C:\xampp\htdocs\Projectsmt4Asli - Copy\resources\views/contentadmin/desa/edit-desa.blade.php ENDPATH**/ ?>