<?php $__env->startSection('content-admin'); ?>
    <div class="container-fluid" id="container-wrapper">
        <!-- Row -->
        <div class="row">
            <!-- DataTable -->
            <div class="col-lg-12">
                <div class="card mb-4 p-3">
                    <table id="example1" class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Email</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $dataPetugas2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="odd">
                                    
                                    <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($pg->name); ?></td>
                                    <td><?php echo e($pg->name); ?></td>
                                    <td>
                                        <a href="#" class="btn btn-sm btn-info">Detail</a> - <a href="#"
                                            class="btn btn-sm btn-danger">Hapus</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--Row-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projectsmt4Asli - Copy\resources\views/contentadmin/petugas/petugas2.blade.php ENDPATH**/ ?>