 <!-- Modal -->
 <div class="modal fade" id="modalEditArt<?php echo e($art->id); ?>" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Edit Data Artikel</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             
             <form action="<?php echo e('admin-artikelUpdate', $art->id); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <div class="modal-body">
                     <div class="form-group">
                         <div class="form-group">
                             <label for="judul">Judul</label>
                             <input type="text" class="form-control" name="judul" id="judul" placeholder="Enter Judul "
                                 value="<?php echo e($art->judul); ?>">
                         </div>
                     </div>
                     <div class="form-group">
                         <label for="user-option">Nama Kategori Artikel</label>
                         <select class="form-control" id="id_kategori" name="id_kategori">
                             <option><?php echo e($art->katFK->nama_kategori); ?></option>
                             <option>-Pilih Kategori-</option>
                             <?php $__currentLoopData = $dataKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($ktg->id); ?>"><?php echo e($ktg->nama_kategori); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                     </div>
                     <div class="form-group">
                         <div class="custom-file">
                             <input type="file" class="custom-file-input" name="foto" id="foto"
                                 value="<?php echo e($art->foto); ?>">
                             <label class="custom-file-label" for="foto">Input Images</label>
                         </div>
                     </div>
                     <div class="form-group">
                         <div class="form-group">
                             <label for="video">Video</label>
                             <input type="text" class="form-control" name="video" id="video"
                                 placeholder="Enter Video " value="<?php echo e($art->video); ?>">
                         </div>
                     </div>
                     <div class="form-group">
                         <label for="deskripsi">Deskripsi Artikel</label>
                         <input id="deskripsi" type="hidden" name="deskripsi" value="<?php echo e($art->deskripsi); ?>">
                         <trix-editor input="deskripsi"></trix-editor>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Simpan</button>
                 </div>
             </form>
             
         </div>
     </div>
 </div>
<?php /**PATH C:\xampp\htdocs\_A\Projectsmt4\resources\views/contentadmin/artikel/edit-artikel.blade.php ENDPATH**/ ?>