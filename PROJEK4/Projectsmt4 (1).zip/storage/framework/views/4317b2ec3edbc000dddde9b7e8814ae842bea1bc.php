 <!-- Modal -->
 <div class="modal fade" id="inputModalKec" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog modal-lg" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kecamatan</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             
             <form action="<?php echo e(route('admin-kecamatanStore')); ?>" method="POST">
                 <?php echo csrf_field(); ?>
                 <div class="modal-body">
                     <div class="form-group">
                         <label for="Nama">Nama Kecamatan</label>
                         <input type="text" class="form-control" name="nama_kecamatan" id="nama_kecamatan"
                             placeholder="Enter Nama " value="<?php echo e(old('nama_kecamatan')); ?>">
                         <?php $__errorArgs = ['nama_kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span class="text-danger"><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Close</button>
                     <button type="submit" class="btn btn-primary">Simpan</button>
                 </div>
             </form>
             
         </div>
     </div>
 </div>
<?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/contentadmin/kecamatan/input-kecamatan.blade.php ENDPATH**/ ?>