<?php $__env->startSection('content-landing'); ?>
    <section class="hero-wrap" style="background-color: azure;" data-stellar-background-ratio="0.3">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center">
                <div class="row gx-5 ftco-animate d-flex align-items-center">
                    <div class="col-lg-6">
                        <div class="mb-5 text-lg-start">
                            <div class="text">
                                <h1 class="mb-4">Masalah Pertanian <span>Dapat Teratasi dengan GoFarm</span>
                                </h1>
                                <p style="font-size: 18px;">Aplikasi website untuk menangani permasalahan di bidang
                                    pertanian <span>secara cepat dan mudah</span> </p>
                                <div class="d-flex meta">
                                    <div class="">
                                        <p class="mb-0"><a href="#" style="border-radius: 500px;"
                                                class="btn btn-primary py-3 px-2 px-md-4">Mulai Jelajah</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div><img style="height: 500px; margin-left: 100px;"
                                src="<?php echo e(asset('landing/images/gambar1.png')); ?>" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section ftco-no-pb ftco-no-pt bg-primary">
        <div class="container">
            <div class="row d-flex justify-content-center  no-gutters">
                <div class="col-md-3 d-flex align-items-stretch ftco-animate">
                    <div class="media block-6 services services-bg d-block text-center px-4 py-5">
                        <div class="icon d-flex justify-content-center align-items-center"><img
                                src="<?php echo e(asset('landing/images/artikel.png')); ?>" alt=""></div>
                        <div class="media-body py-md-4">
                            <h3>Artikel</h3>
                            <p>A small river named Duden flows by their place and supplies it with the necessary
                                regelialia.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 d-flex align-items-stretch ftco-animate">
                    <div class="media block-6 services services-bg services-darken d-block text-center px-4 py-5">
                        <div class="icon d-flex justify-content-center align-items-center"><img
                                src="<?php echo e(asset('landing/images/chat.png')); ?>" alt=""></div>
                        <div class="media-body py-md-4">
                            <h3>Chat</h3>
                            <p>A small river named Duden flows by their place and supplies it with the necessary
                                regelialia.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 d-flex align-items-stretch ftco-animate">
                    <div class="media block-6 services services-bg services-lighten d-block text-center px-4 py-5">
                        <div class="icon d-flex justify-content-center align-items-center"><img
                                src="<?php echo e(asset('landing/images/teman.png')); ?>" alt=""></div>
                        <div class="media-body py-md-4">
                            <h3>Relasi Petani</h3>
                            <p>A small river named Duden flows by their place and supplies it with the necessary
                                regelialia.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section ftco-portfolio">

        <div class="container">
            <div class="row no-gutters">
                <div class="col-md-12 portfolio-wrap">
                    <div class="row no-gutters align-items-center">
                        <div class="col-md-5 img js-fullheight" style="background-image: url(<?php echo e(asset('landing/images/petani1.png')); ?>);">

                        </div>
                        <div class="col-md-7">
                            <div class="text pt-5 pl-0 pl-lg-5 pl-md-4 ftco-animate">
                                <div class="px-4 px-lg-4">
                                    <div class="desc">
                                        <div class="top">
                                            <!-- <span class="subheading">Exterior {12/07/2020}</span> -->
                                            <h2 class="mb-4"><a href="work.html">Petani Indonesai <br>
                                                    Maju</a></h2>
                                        </div>
                                        <div class="absolute">
                                            <p>Salah satu cara untuk mendukung para petani Indonesia dalam mengatasi
                                                permasalahan
                                                dibidang pertanian yakni memberikan solusi untuk bertukar informasi
                                                di bidang pertanian melalui aplikasi SiTans</p>
                                            <p><a href="#" class="custom-btn">Info lebih lanjut</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 portfolio-wrap">
                    <div class="row no-gutters align-items-center">
                        <div class="col-md-5 order-md-last img js-fullheight"
                            style="background-image: url(<?php echo e(asset('landing/images/petani2.png')); ?>);">

                        </div>
                        <div class="col-md-7">
                            <div class="text pt-5 pr-md-5 ftco-animate">
                                <div class="px-4 px-lg-4">
                                    <div class="desc text-md-right">
                                        <div class="top">
                                            <h2 class="mb-4"><a style="font-size: 55px;" href="#">Pentingnya
                                                    <br> Penyuluhan dibidang <br> Pertanian</a></h2>
                                        </div>
                                        <div class="absolute">
                                            <p>Penyuluhan dapat juga berperan dalam menyampaikan informasi dibidang
                                                pertanian,
                                                memberikan dorongan bagi para petani, dan juga penyampaian aspirasi
                                                petani. </p>
                                            <p><a href="#" class="custom-btn">Info lebih lanjut</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 portfolio-wrap">
                    <div class="row no-gutters align-items-center">
                        <div class="col-md-5 img js-fullheight" style="background-image: url(<?php echo e(asset('landing/images/work-3.jpg')); ?>);">

                        </div>
                        <div class="col-md-7">
                            <div class="text pt-5 pl-md-5 pl-md-4 ftco-animate">
                                <div class="px-4 px-lg-4">
                                    <div class="desc">
                                        <div class="top">
                                            <span class="subheading">Building {12/07/2020}</span>
                                            <h2 class="mb-4"><a href="work.html">Cultural Complex Centre</a>
                                            </h2>
                                        </div>
                                        <div class="absolute">
                                            <p>Far far away, behind the word mountains, far from the countries Vokalia
                                                and Consonantia, there live the blind texts. Separated they live in
                                                Bookmarksgrove.</p>
                                            <p><a href="#" class="custom-btn">View Portfolio</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 portfolio-wrap">
                    <div class="row no-gutters align-items-center">
                        <div class="col-md-5 order-md-last img js-fullheight"
                            style="background-image: url(<?php echo e(asset('landing/images/work-4.jpg')); ?>);">

                        </div>
                        <div class="col-md-7">
                            <div class="text pt-5 pr-md-5 ftco-animate">
                                <div class="px-4 px-lg-4">
                                    <div class="desc text-md-right">
                                        <div class="top">
                                            <span class="subheading">Furniture {12/07/2020}</span>
                                            <h2 class="mb-4"><a href="work.html">Twin Office</a></h2>
                                        </div>
                                        <div class="absolute">
                                            <p>Far far away, behind the word mountains, far from the countries Vokalia
                                                and Consonantia, there live the blind texts. Separated they live in
                                                Bookmarksgrove.</p>
                                            <p><a href="#" class="custom-btn">View Portfolio</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 portfolio-wrap">
                    <div class="row no-gutters align-items-center">
                        <div class="col-md-5 img js-fullheight" style="background-image: url(<?php echo e(asset('landing/images/work-5.jpg')); ?>);">

                        </div>
                        <div class="col-md-7">
                            <div class="text pt-5 pl-md-5 pl-md-4 ftco-animate">
                                <div class="px-4 px-lg-4">
                                    <div class="desc">
                                        <div class="top">
                                            <span class="subheading">Building {12/07/2020}</span>
                                            <h2 class="mb-4"><a href="work.html">Cultural Complex Centre</a>
                                            </h2>
                                        </div>
                                        <div class="absolute">
                                            <p>Far far away, behind the word mountains, far from the countries Vokalia
                                                and Consonantia, there live the blind texts. Separated they live in
                                                Bookmarksgrove.</p>
                                            <p><a href="#" class="custom-btn">View Portfolio</a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <span class="subheading">Artikel</span>
                    <h2 class="mb-3">Happy Reading</h2>
                </div>
            </div>
            <div class="row ftco-animate">
                <div class="col-md-12">
                    <div class="carousel-testimony owl-carousel">
                        <div class="item">
                            <div class="testimony-wrap py-4">
                                <div class="text">
                                    <span class="fa fa-quote-left"></span>
                                    <p class="mb-4">Far far away, behind the word mountains, far from the
                                        countries Vokalia and Consonantia, there live the blind texts.</p>
                                    <div class="d-flex align-items-center">
                                        <div class="user-img" style="background-image: url(<?php echo e(asset('landing/images/artikel1.png')); ?>)">
                                        </div>
                                        <div class="pl-3">
                                            <p class="name">Roger Scott</p>
                                            <span class="position">Marketing Manager</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap py-4">
                                <div class="text">
                                    <span class="fa fa-quote-left"></span>
                                    <p class="mb-4">Far far away, behind the word mountains, far from the
                                        countries Vokalia and Consonantia, there live the blind texts.</p>
                                    <div class="d-flex align-items-center">
                                        <div class="user-img" style="background-image: url(<?php echo e(asset('landing/images/artikel2.png')); ?>)">
                                        </div>
                                        <div class="pl-3">
                                            <p class="name">Roger Scott</p>
                                            <span class="position">Marketing Manager</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap py-4">
                                <div class="text">
                                    <span class="fa fa-quote-left"></span>
                                    <p class="mb-4">Far far away, behind the word mountains, far from the
                                        countries Vokalia and Consonantia, there live the blind texts.</p>
                                    <div class="d-flex align-items-center">
                                        <div class="user-img" style="background-image: url(<?php echo e(asset('landing/images/artikel3.png')); ?>)">
                                        </div>
                                        <div class="pl-3">
                                            <p class="name">Roger Scott</p>
                                            <span class="position">Marketing Manager</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap py-4">
                                <div class="text">
                                    <span class="fa fa-quote-left"></span>
                                    <p class="mb-4">Far far away, behind the word mountains, far from the
                                        countries Vokalia and Consonantia, there live the blind texts.</p>
                                    <div class="d-flex align-items-center">
                                        <div class="user-img" style="background-image: url(<?php echo e(asset('landing/images/person_1.jpg')); ?>)">
                                        </div>
                                        <div class="pl-3">
                                            <p class="name">Roger Scott</p>
                                            <span class="position">Marketing Manager</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap py-4">
                                <div class="text">
                                    <span class="fa fa-quote-left"></span>
                                    <p class="mb-4">Far far away, behind the word mountains, far from the
                                        countries Vokalia and Consonantia, there live the blind texts.</p>
                                    <div class="d-flex align-items-center">
                                        <div class="user-img" style="background-image: url(<?php echo e(asset('landing/images/person_2.jpg')); ?>)">
                                        </div>
                                        <div class="pl-3">
                                            <p class="name">Roger Scott</p>
                                            <span class="position">Marketing Manager</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/content-landing/beranda.blade.php ENDPATH**/ ?>