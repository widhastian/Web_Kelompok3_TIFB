<?php $__env->startPush('style-custom'); ?>
    <style>
        .dblock {
            white-space: nowrap;
            width: 95px;
            overflow: hidden;
            text-overflow: ellipsis;
            /* border: 1px solid #000000; */
        }

    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content-admin'); ?>
    <!-- Row -->
    <div class="row">
        <!-- DataTable -->
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header">
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#inputModalDes"
                        id="#myBtn">
                        <i class="fas fa-fw fa-plus"></i> Tambah Data
                    </button>
                    <?php echo $__env->make('contentadmin.artikel.input-artikel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <?php if(Auth::user()->id_level == 1): ?>
                                    <th scope="col">Petugas</th>
                                <?php endif; ?>
                                <th scope="col">Judul</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Video</th>
                                <th scope="col">Deskripsi</th>
                                <th scope="col">Kategori Artikel</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataArtikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="odd">
                                    <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                                    <?php if(Auth::user()->id_level == 1): ?>
                                        <td>
                                            <div class="dblock"><?php echo e($art->userFK->name); ?></div>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="dblock"><?php echo e($art['judul']); ?></div>
                                    </td>
                                    <td> <img src="<?php echo e(asset('files/artikel/' . $art['foto'])); ?>" style="width: 68px"
                                            alt="foto ni ges"></td>
                                    <td>
                                        <div class="dblock"><?php echo e($art['video']); ?></div>
                                    </td>
                                    <td>
                                        <div class="dblock"><?php echo e($art['deskripsi']); ?></div>
                                    </td>
                                    <?php if(Auth::user()->id_level != 1): ?>
                                        <td><?php echo e($art['kategori']); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($art->katFK->nama_kategori); ?></td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="" class="btn btn-sm btn-info" data-toggle="modal"
                                            data-target="#modalEditArt<?php echo e($art['id']); ?>">
                                            <i class="fas fa-fw fa-pencil-alt"></i>
                                        </a>
                                        <a href="<?php echo e(route('deleteArt', $art['id'])); ?>" class="btn btn-sm btn-danger"><i
                                                class="fas fa-fw fa-trash-alt"></i></a>
                                    </td>
                                    <?php echo $__env->make('contentadmin.artikel.edit-artikel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
    <!--Row-->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_A\Projectsmt4\resources\views/contentadmin/artikel/artikel.blade.php ENDPATH**/ ?>