   
   <?php $__env->startSection('content-front'); ?>
       <!-- Hero Section Begin -->
       <section class="hero">
           <div class="hero__slider owl-carousel">
               <div class="hero__items set-bg" data-setbg="<?php echo e(asset('assets/frontend/img/hero/hero-1.jpg')); ?>">
                   <div class="container">
                       <div class="row">
                           <div class="col-xl-5 col-lg-7 col-md-8">
                               <div class="hero__text">
                                   <h6>Summer Collection</h6>
                                   <h2>Fall - Winter Collections 2030</h2>
                                   <p>A specialist label creating luxury essentials. Ethically crafted with an unwavering
                                       commitment to exceptional quality.</p>
                                   <a href="#" class="primary-btn">Shop now <span class="arrow_right"></span></a>
                                   <div class="hero__social">
                                       <a href="#"><i class="fa fa-facebook"></i></a>
                                       <a href="#"><i class="fa fa-twitter"></i></a>
                                       <a href="#"><i class="fa fa-pinterest"></i></a>
                                       <a href="#"><i class="fa fa-instagram"></i></a>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
               <div class="hero__items set-bg" data-setbg="<?php echo e(asset('assets/frontend/img/hero/hero-2.jpg')); ?>">
                   <div class="container">
                       <div class="row">
                           <div class="col-xl-5 col-lg-7 col-md-8">
                               <div class="hero__text">
                                   <h6>Summer Collection</h6>
                                   <h2>Fall - Winter Collections 2030</h2>
                                   <p>A specialist label creating luxury essentials. Ethically crafted with an unwavering
                                       commitment to exceptional quality.</p>
                                   <a href="#" class="primary-btn">Shop now <span class="arrow_right"></span></a>
                                   <div class="hero__social">
                                       <a href="#"><i class="fa fa-facebook"></i></a>
                                       <a href="#"><i class="fa fa-twitter"></i></a>
                                       <a href="#"><i class="fa fa-pinterest"></i></a>
                                       <a href="#"><i class="fa fa-instagram"></i></a>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </section>
       <!-- Hero Section End -->

       <!-- Banner Section Begin -->
       <section class="banner spad">
           <div class="container">
               <div class="row">
                   <div class="col-lg-7 offset-lg-4">
                       <div class="banner__item">
                           <div class="banner__item__pic">
                               <img src="<?php echo e(asset('assets/frontend/img/banner/banner-1.jpg')); ?>" alt="">
                           </div>
                           <div class="banner__item__text">
                               <h2>Clothing Collections 2030</h2>
                               <a href="#">Shop now</a>
                           </div>
                       </div>
                   </div>
                   <div class="col-lg-5">
                       <div class="banner__item banner__item--middle">
                           <div class="banner__item__pic">
                               <img src="<?php echo e(asset('assets/frontend/img/banner/banner-2.jpg')); ?>" alt="">
                           </div>
                           <div class="banner__item__text">
                               <h2>Accessories</h2>
                               <a href="#">Shop now</a>
                           </div>
                       </div>
                   </div>
                   <div class="col-lg-7">
                       <div class="banner__item banner__item--last">
                           <div class="banner__item__pic">
                               <img src="<?php echo e(asset('assets/frontend/img/banner/banner-3.jpg')); ?>" alt="">
                           </div>
                           <div class="banner__item__text">
                               <h2>Shoes Spring 2030</h2>
                               <a href="#">Shop now</a>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </section>
       <!-- Banner Section End -->

       <!-- Latest Blog Section Begin -->
       <section class="latest spad">
           <div class="container">
               <div class="row">
                   <div class="col-lg-12">
                       <div class="section-title">
                           <span>Latest News</span>
                           <h2>Fashion New Trends</h2>
                       </div>
                   </div>
               </div>
               <div class="row">
                   <div class="col-lg-4 col-md-6 col-sm-6">
                       <div class="blog__item">
                           <div class="blog__item__pic set-bg"
                               data-setbg="<?php echo e(asset('assets/frontend/img/blog/blog-1.jpg')); ?>"></div>
                           <div class="blog__item__text">
                               <span><img src="<?php echo e(asset('assets/frontend/img/icon/calendar.png')); ?>" alt=""> 16 February
                                   2020</span>
                               <h5>What Curling Irons Are The Best Ones</h5>
                               <a href="#">Read More</a>
                           </div>
                       </div>
                   </div>
                   <div class="col-lg-4 col-md-6 col-sm-6">
                       <div class="blog__item">
                           <div class="blog__item__pic set-bg"
                               data-setbg="<?php echo e(asset('assets/frontend/img/blog/blog-2.jpg')); ?>"></div>
                           <div class="blog__item__text">
                               <span><img src="<?php echo e(asset('assets/frontend/img/icon/calendar.png')); ?>" alt=""> 21 February
                                   2020</span>
                               <h5>Eternity Bands Do Last Forever</h5>
                               <a href="#">Read More</a>
                           </div>
                       </div>
                   </div>
                   <div class="col-lg-4 col-md-6 col-sm-6">
                       <div class="blog__item">
                           <div class="blog__item__pic set-bg"
                               data-setbg="<?php echo e(asset('assets/frontend/img/blog/blog-3.jpg')); ?>"></div>
                           <div class="blog__item__text">
                               <span><img src="<?php echo e(asset('assets/frontend/img/icon/calendar.png')); ?>" alt=""> 28 February
                                   2020</span>
                               <h5>The Health Benefits Of Sunglasses</h5>
                               <a href="#">Read More</a>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </section>
       <!-- Latest Blog Section End -->
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/frontend/beranda.blade.php ENDPATH**/ ?>