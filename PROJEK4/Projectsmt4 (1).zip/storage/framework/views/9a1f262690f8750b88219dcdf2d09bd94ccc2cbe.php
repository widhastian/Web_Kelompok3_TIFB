<?php $__env->startSection('content-admin'); ?>
    <!-- Row -->
    <div class="row">
        <!-- DataTable -->
        <div class="col-lg-12">
            <div class="card mb-4">
                <div class="card-header">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#inputModalDes"
                        id="#myBtn">
                        <i class="fas fa-fw fa-plus"></i> Tambah Data
                    </button>
                    <?php echo $__env->make('contentadmin.artikel.input-artikel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Foto</th>
                                <th scope="col">Video</th>
                                <th scope="col">Petugas</th>
                                <th scope="col">Kategori Artikel</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataArtikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Auth::user()->id == $art->id_user): ?>
                                    <tr role="row" class="odd">
                                        <td class="sorting_1"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($art->foto); ?></td>
                                        <td><?php echo e($art->video); ?></td>
                                        <td><?php echo e($art->deskripsi); ?></td>
                                        <td><?php echo e($art->katFK->nama_kategori); ?></td>
                                        <td>
                                            <a href="" class="btn btn-sm btn-info" data-toggle="modal"
                                                data-target="#modalEditDes<?php echo e($art->id); ?>">
                                                <i class="fas fa-fw fa-pencil-alt"></i>
                                            </a> -
                                            <a href="<?php echo e(route('deleteDes', $art->id)); ?>" class="btn btn-sm btn-danger"><i
                                                    class="fas fa-fw fa-trash-alt"></i></a>
                                        </td>
                                        
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
    <!--Row-->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projectsmt4Asli - Copy\resources\views/contentadmin/artikel/arikel.blade.php ENDPATH**/ ?>