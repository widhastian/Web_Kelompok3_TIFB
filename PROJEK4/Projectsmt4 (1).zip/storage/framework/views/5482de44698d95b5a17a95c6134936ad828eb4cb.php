<?php $__env->startPush('style-custom'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css'>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-landing'); ?>
    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-12 col-md-10 col-lg-8 ftco-animate fadeInUp">
                    <div class="">
                        <div class="chat">
                            <div class="contact bar">
                                <div class="pic stark"
                                    style="background-image: url(<?php echo e(asset('files/foto-profile/' . $user['fotoPetugas'])); ?>)">
                                </div>
                                <div class="name">
                                    <?php echo e($user['namaPetugas']); ?>

                                </div>
                                <div class="seen">
                                    Today at 12:56
                                </div>
                            </div>
                            <div class="messages" id="listPesan">
                                <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($p->id_user == $user['idPetugas']): ?>
                                        <div class="message stark">
                                            <?php echo e($p->isi); ?>

                                        </div>
                                    <?php else: ?>
                                        <div class="message parker">
                                            <?php echo e($p->isi); ?>

                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="input">
                                <i class="fas fa-camera"></i><i class="far fa-laugh-beam"></i>
                                <input type="text" name="pesanTeks" id="pesanTeks" placeholder="Type your message here!"
                                    type="text" />
                                <input type="hidden" name="idPk" id="idPk" value="<?php echo e($user['idPck']); ?>" />
                                <input type="hidden" name="idPtg" id="idPtg" value="<?php echo e($user['idPetugas']); ?>">
                                <i class="fas fa-paper-plane" id="btnKirim"></i>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script-custom'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            setInterval(loadData, 1000);
            myscrol();

            $(".fa-camera").click(function() {
                // alert('sudah diklik')
                loadData();
            });

            $("#btnKirim").click(function() {
                kirimPesan();
                setTimeout(loadData, 100);
                setTimeout(myscrol, 800);
            });
        });

        function loadData() {
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('landing-chatRealtime')); ?>",
                data: {},
                dataType: "text",
                success: function(data) {
                    if (data != 0) {
                        $("#listPesan").empty()
                        $("#listPesan").html(data)
                    }
                }
            });
        }

        function kirimPesan() {
            var teks = $("input[name=pesanTeks]").val();
            var pck = $("input[name=idPk]").val();
            var ptg = $("input[name=idPtg]").val();
            // alert(pck);
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('landing-chatStore')); ?>",
                data: {
                    pesanTeks: teks,
                    idPk: pck,
                    idPtg: ptg,
                },
                success: function(data) {
                    $("input[name=pesanTeks]").val('');
                    $("input[name=idPk]").val(data.idPck);
                    $("#listPesan").html(data.pesan);
                    myscrol();
                }
            });
        }

        function myscrol() {
            var chat = document.getElementById('listPesan');
            chat.scrollTop = chat.scrollHeight - chat.clientHeight;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.landing.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kampusMerdeka\Projectsmt4\resources\views/content-landing/chat.blade.php ENDPATH**/ ?>